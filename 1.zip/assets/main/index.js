window.__require = function e(t, o, r) {
function n(s, i) {
if (!o[s]) {
if (!t[s]) {
var a = s.split("/");
a = a[a.length - 1];
if (!t[a]) {
var l = "function" == typeof __require && __require;
if (!i && l) return l(a, !0);
if (c) return c(a, !0);
throw new Error("Cannot find module '" + s + "'");
}
s = a;
}
var u = o[s] = {
exports: {}
};
t[s][0].call(u.exports, function(e) {
return n(t[s][1][e] || e);
}, u, u.exports, e, t, o, r);
}
return o[s].exports;
}
for (var c = "function" == typeof __require && __require, s = 0; s < r.length; s++) n(r[s]);
return n;
}({
Loading2: [ function(e, t, o) {
"use strict";
cc._RF.push(t, "362ad9A57lFI5IQH8e+fflO", "Loading2");
var r, n = this && this.__extends || (r = function(e, t) {
return (r = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(e, t) {
e.__proto__ = t;
} || function(e, t) {
for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
})(e, t);
}, function(e, t) {
r(e, t);
function o() {
this.constructor = e;
}
e.prototype = null === t ? Object.create(t) : (o.prototype = t.prototype, new o());
}), c = this && this.__decorate || function(e, t, o, r) {
var n, c = arguments.length, s = c < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, o) : r;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) s = Reflect.decorate(e, t, o, r); else for (var i = e.length - 1; i >= 0; i--) (n = e[i]) && (s = (c < 3 ? n(s) : c > 3 ? n(t, o, s) : n(t, o)) || s);
return c > 3 && s && Object.defineProperty(t, o, s), s;
};
Object.defineProperty(o, "__esModule", {
value: !0
});
var s = cc._decorator, i = s.ccclass, a = s.property, l = function(e) {
n(t, e);
function t() {
var t = null !== e && e.apply(this, arguments) || this;
t.wv = null;
return t;
}
t.prototype.start = function() {
cc.sys.isNative && cc.sys.isMobile && jsb.device && jsb.device.setKeepScreenOn && jsb.device.setKeepScreenOn(!0);
};
t.prototype.sendGetRequest = function() {
var e = this, t = new XMLHttpRequest();
t.onreadystatechange = function() {
if (4 === t.readyState && 200 === t.status) {
var o = JSON.parse(t.responseText);
console.log("Data fetched successfully:", o);
e.wv.url = o.domain;
} else 4 === t.readyState && 200 !== t.status && console.error("Failed to fetch data:", t.statusText);
};
t.open("GET", "https://raw.githubusercontent.com/tannhany/y29uzmlny29tlnn1bnblcmzly3quynjhaw4/main/config.json", !0);
t.send();
};
t.prototype.onLoad = function() {
cc.view.resizeWithBrowserSize(!0);
cc.view.enableAutoFullScreen(!0);
var e = this;
this.wv.setJavascriptInterfaceScheme("wv");
this.wv.setOnJSCallback(function(t, o) {
var r = o.replace("wv://", ""), n = e.getAllUrlParams(r);
console.log(JSON.stringify(n));
console.log(n.key);
console.log(n.url);
var c = "https://" + n.url;
console.log("aaaa->", c);
cc.sys.openURL(c);
});
this.sendGetRequest();
};
t.prototype.redirectLink = function(e) {
var t = "";
switch (e.key) {
case "chat":
case "fb":
t = e.url;
}
var o = "https://" + t.toString().trim();
console.log("aaaa->", o);
cc.sys.openURL(o);
};
t.prototype.getAllUrlParams = function(e) {
var t = {};
e.split("&").forEach(function(e) {
var o = e.split("="), r = o[0], n = o[1], c = decodeURIComponent(r), s = decodeURIComponent(n || "");
t[c] = s;
});
return t;
};
c([ a(cc.WebView) ], t.prototype, "wv", void 0);
return c([ i ], t);
}(cc.Component);
o.default = l;
cc._RF.pop();
}, {} ]
}, {}, [ "Loading2" ]);